import {loadEnv,build} from 'vite';
const env={...loadEnv('production',process.cwd(),'VITE_'),...process.env};
if(env.VITE_APP_MODE!=='cloud'||!env.VITE_CLOUDBASE_ENV_ID){throw Error('请先在 .env.local 配置 VITE_APP_MODE=cloud 和真实 VITE_CLOUDBASE_ENV_ID，再构建云端网页。')}
await build({configFile:'vite.single.config.ts'});
