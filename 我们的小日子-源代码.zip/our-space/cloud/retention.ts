import type {Repository,SpaceState,StoredMemory,MediaDoc} from './core';
export async function runRetention(repo:Repository,deleteFile:(fileId:string)=>Promise<void>,now:number){
 let recordsRemoved=0,filesRemoved=0;
 async function all<T>(collection:string){const records:T[]=[];let after='';for(;;){const page=await repo.page<T&{id:string}>(collection,after,50);records.push(...page);if(page.length<50)break;after=page.at(-1)!.id;}return records;}
 for(const item of await all<StoredMemory>('memories')){const removed=await repo.transaction(async tx=>{const current=await tx.get<StoredMemory>('memories',item.id);if(!current?.deletedAt||now-current.deletedAt<30*86400000)return false;const s=await tx.get<SpaceState>('spaces','singleton');if(!s)return false;delete s.slots[item.id];s.revision++;await tx.remove('memories',item.id);await tx.set('spaces','singleton',s);return true;});if(removed)recordsRemoved++;}
 const before=await repo.get<SpaceState>('spaces','singleton');if(!before)return {recordsRemoved,filesRemoved};
 const references=new Set((await all<StoredMemory>('memories')).flatMap(m=>m.images));
 const after=await repo.get<SpaceState>('spaces','singleton');if(after?.revision!==before.revision)return {recordsRemoved,filesRemoved};
 let expected=before.revision;
 for(const candidate of await all<MediaDoc>('media')){
  if(references.has(candidate.id)||now-candidate.createdAt<86400000)continue;
  const marked=await repo.transaction(async tx=>{const s=await tx.get<SpaceState>('spaces','singleton');if(!s||s.revision!==expected)return null;const m=await tx.get<MediaDoc>('media',candidate.id);if(!m||m.fileId!==candidate.fileId||now-m.createdAt<86400000)return null;m.state='deleting';s.revision++;await tx.set('media',m.id,m);await tx.set('spaces','singleton',s);return {fileId:m.fileId,revision:s.revision};});
  if(!marked)break;expected=marked.revision;
  await deleteFile(marked.fileId);
  const end=await repo.transaction(async tx=>{const s=await tx.get<SpaceState>('spaces','singleton');const m=await tx.get<MediaDoc>('media',candidate.id);if(!s||m?.state!=='deleting'||m.fileId!==marked.fileId)throw Error('Media cleanup changed unexpectedly');const concurrent=s.revision!==expected;await tx.remove('media',candidate.id);s.revision++;await tx.set('spaces','singleton',s);return {concurrent,revision:s.revision};});filesRemoved++;expected=end.revision;if(end.concurrent)break;
 }
 return {recordsRemoved,filesRemoved};
}
