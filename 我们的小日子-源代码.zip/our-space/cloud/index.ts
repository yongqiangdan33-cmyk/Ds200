import cloudbase from '@cloudbase/node-sdk';
import jpeg from 'jpeg-js';
import {ApiError,createApi,type MediaStore} from './core';
import {createRepository} from './repository';

const app=cloudbase.init({env:cloudbase.SYMBOL_CURRENT_ENV});
const repo=createRepository(app.database());
const media:MediaStore={
 async put(id,base64){let input:Buffer;try{input=Buffer.from(base64,'base64');if(input.toString('base64')!==base64)throw Error();}catch{throw new ApiError('VALIDATION','照片格式无效')};if(input.length>1650000)throw new ApiError('VALIDATION','照片展示版本过大');let decoded:ReturnType<typeof jpeg.decode>;try{decoded=jpeg.decode(input,{maxResolutionInMP:6,maxMemoryUsageInMB:128,tolerantDecoding:false});}catch{throw new ApiError('VALIDATION','无法读取这张照片')};if(decoded.width>2400||decoded.height>2400||!decoded.width||!decoded.height)throw new ApiError('VALIDATION','照片尺寸无效');const clean=jpeg.encode({width:decoded.width,height:decoded.height,data:decoded.data},85).data;const response=await app.uploadFile({cloudPath:`our-space/${id}.jpg`,fileContent:clean});if(!response.fileID)throw new ApiError('MEDIA_FAILED','照片上传失败，请重试');return response.fileID;},
 async url(fileIds){const response=await app.getTempFileURL({fileList:fileIds.map(fileID=>({fileID,maxAge:300}))});const map=new Map(response.fileList.map(x=>[x.fileID,x]));return fileIds.map(id=>{const entry=map.get(id);if(!entry?.tempFileURL||entry.code!=='SUCCESS')throw new ApiError('MEDIA_FAILED','照片暂时无法读取');return entry.tempFileURL;});}
};
const dispatch=createApi(repo,media,{ownerUid:process.env.SPACE_OWNER_UID??''});
export async function main(event:unknown){try{const identity=app.auth().getUserInfo();if(!identity?.uid||identity.isAnonymous)throw new ApiError('UNAUTHENTICATED','请使用正式账号登录');if(!process.env.SPACE_OWNER_UID)throw new ApiError('CONFIGURATION','空间尚未配置');return {ok:true,data:await dispatch(identity.uid,event)}}catch(error){if(error instanceof ApiError)return {ok:false,error:{code:error.code,message:error.message}};return {ok:false,error:{code:'SERVICE_FAILED',message:'服务暂时无法完成请求，请稍后重试'}};}}
