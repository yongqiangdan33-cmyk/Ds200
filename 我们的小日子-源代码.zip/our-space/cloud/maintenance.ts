import cloudbase from '@cloudbase/node-sdk';
import {createRepository} from './repository';
import {runRetention} from './retention';
const app=cloudbase.init({env:cloudbase.SYMBOL_CURRENT_ENV});
// This function must have invoke:false for all client identities. Only a trusted timer/admin may invoke it.
export async function main(){return runRetention(createRepository(app.database()),async fileId=>{const result=await app.deleteFile({fileList:[fileId]});if(result.fileList.some(x=>x.code!=='SUCCESS'))throw Error('File cleanup failed')},Date.now());}
