import type {DocAccess,Repository} from './core';
export type CloudDb={collection:(name:string)=>any;runTransaction:(callback:(tx:{collection:(name:string)=>any})=>Promise<any>)=>Promise<any>;command:{gt:(value:string)=>unknown}};
const check=(response:any)=>{if(response?.code)throw Object.assign(Error('Cloud database request failed'),{code:response.code});return response};
function access(source:{collection:(name:string)=>any}):DocAccess{return {
 async get<T>(collection:string,id:string){const response=check(await source.collection(collection).doc(id).get());const data=Array.isArray(response.data)?response.data[0]:response.data;if(!data)return null;const {_id,...value}=data;return value as T;},
 async set(collection,id,value){check(await source.collection(collection).doc(id).set(value))},
 async remove(collection,id){check(await source.collection(collection).doc(id).remove())}
};}
export function createRepository(db:CloudDb):Repository{return {...access(db),async transaction(fn){return db.runTransaction(async tx=>fn(access(tx)))},async page<T>(collection:string,after:string,limit:number){let query=db.collection(collection).orderBy('_id','asc').limit(limit);if(after)query=query.where({_id:db.command.gt(after)});const response=check(await query.get());return response.data.map(({_id,...value}:any)=>value as T)}};}
