import 'fake-indexeddb/auto';
import {describe,it,expect} from 'vitest';
import {storage} from '../src/storage';
import {type Memory} from '../src/domain';
const make=(id:string):Memory=>({id,kind:'artifact',title:id,story:'',date:'',year:'',images:[],createdAt:1});
describe('本地记录事务',()=>{
 it('并发编辑时拒绝旧版本，保留先保存的修改',async()=>{await storage.save(make('race'));const first=(await storage.list()).find(x=>x.id==='race')!;const stale={...first};await storage.save({...first,title:'先保存'});await expect(storage.save({...stale,title:'旧版本'})).rejects.toThrow('已经改变');expect((await storage.list()).find(x=>x.id==='race')?.title).toBe('先保存')});
 it('恢复后进行清理不会删除已恢复记录',async()=>{await storage.save({...make('restored'),deletedAt:1});const trashed=(await storage.list()).find(x=>x.id==='restored')!;await storage.save({...trashed,deletedAt:undefined});await storage.purgeExpired(40*86400000);expect((await storage.list()).some(x=>x.id==='restored')).toBe(true)});
 it('并发加入展位时不会分配相同位置',async()=>{await Promise.all([storage.save(make('slot-a')),storage.save(make('slot-b'))]);const records=(await storage.list()).filter(x=>x.id==='slot-a'||x.id==='slot-b');expect(records).toHaveLength(2);expect(new Set(records.map(x=>x.slot)).size).toBe(2)});
 it('旧的回收站页面不能永久删除已恢复的记录',async()=>{await storage.save({...make('restore-race'),deletedAt:100});const stale=(await storage.list()).find(x=>x.id==='restore-race')!;await storage.save({...stale,deletedAt:undefined});await expect(storage.removeTrashed(stale.id,stale.version??0)).rejects.toThrow('已改变');expect((await storage.list()).some(x=>x.id===stale.id)).toBe(true)});
 it('拒绝用旧设置覆盖其他标签的新设置',async()=>{const settings=await storage.settings();await storage.saveSettings({...settings,title:'新名称'});await expect(storage.saveSettings({...settings,title:'旧名称'})).rejects.toThrow('其他页面改变');expect((await storage.settings()).title).toBe('新名称')});
});
