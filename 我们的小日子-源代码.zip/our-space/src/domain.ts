export type Kind = 'photo' | 'artifact' | 'occasion' | 'wish';
export interface Memory { id:string; kind:Kind; title:string; story:string; date:string; year:string; images:string[]; done?:boolean; repeat?:boolean; deletedAt?:number; createdAt:number; slot?:number; version?:number; }
export interface Settings { title:string; names:string; startDate:string; timezone:string; version?:number; }
export const defaultSettings:Settings = {title:'我们的小日子',names:'你 & 我',startDate:'',timezone:'Asia/Shanghai'};
export const uid=()=>crypto.randomUUID();
export function localDate(now:Date,zone='Asia/Shanghai') { const p=new Intl.DateTimeFormat('en-CA',{timeZone:zone,year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(now); const v=(k:string)=>p.find(x=>x.type===k)?.value; return `${v('year')}-${v('month')}-${v('day')}`; }
function dayNumber(s:string) { const [y,m,d]=s.split('-').map(Number); const x=new Date(Date.UTC(y,m-1,d)); if(!y||!m||!d||x.getUTCFullYear()!==y||x.getUTCMonth()!==m-1||x.getUTCDate()!==d) throw Error('日期无效'); return Math.floor(x.getTime()/86400000); }
export function dayDifference(start:string,end:string){return dayNumber(end)-dayNumber(start);}
export function nextDate(date:string, repeat:boolean, today:string){ if(!repeat||date>today) return date; const [,m,d]=date.split('-').map(Number); let year=Number(today.slice(0,4)); const make=(y:number)=>`${y}-${String(m).padStart(2,'0')}-${String(m===2&&d===29&&new Date(Date.UTC(y,1,29)).getUTCMonth()!==1?28:d).padStart(2,'0')}`; return make(year)<today?make(year+1):make(year); }
export function dateLabel(item:Pick<Memory,'date'|'year'>){return item.date || item.year || '日期未填写';}
export function sortMemories(items:Memory[]){return [...items].sort((a,b)=>`${b.date||b.year||'0000'}-${b.createdAt}`.localeCompare(`${a.date||a.year||'0000'}-${a.createdAt}`));}
export function availableSlot(items:Memory[],excludeId?:string){const used=new Set(items.filter(m=>m.kind==='artifact'&&!m.deletedAt&&m.id!==excludeId).map(m=>m.slot).filter((v):v is number=>v!==undefined));let slot=0;while(used.has(slot))slot++;return slot;}
export function escapeHtml(s:string){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));}
