import {storage as localStorage} from '../storage';
import {cloudMode,cloudStorage} from './cloud';
import type {Memory} from '../domain';
export {cloudMode} from './cloud';
export const storage=cloudMode?cloudStorage:localStorage;
export const trashMemory=async(memory:Memory)=>cloudMode?cloudStorage.trash(memory):localStorage.save({...memory,deletedAt:Date.now()});
export const restoreMemory=async(memory:Memory)=>cloudMode?cloudStorage.restore(memory):localStorage.save({...memory,deletedAt:undefined});
