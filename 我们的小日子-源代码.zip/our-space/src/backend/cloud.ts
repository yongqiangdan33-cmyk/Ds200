import type {Memory,Settings} from '../domain';
export const cloudMode=import.meta.env.VITE_APP_MODE==='cloud';
export const cloudConfigured=!!import.meta.env.VITE_CLOUDBASE_ENV_ID;
let appPromise:Promise<any>|undefined;
const urlsToIds=new Map<string,string>();
let revision=0;
async function app(){if(!cloudConfigured)throw Error('云端环境尚未配置');if(!appPromise)appPromise=import('@cloudbase/js-sdk').then(({default:cloudbase})=>cloudbase.init({env:import.meta.env.VITE_CLOUDBASE_ENV_ID,region:import.meta.env.VITE_CLOUDBASE_REGION||'ap-shanghai'}));return appPromise;}
export async function rpc<T>(action:string,input?:unknown):Promise<T>{const client=await app();let response;try{response=await client.callFunction({name:import.meta.env.VITE_CLOUDBASE_FUNCTION||'our-space-api',data:{action,input},parse:true})}catch{throw Error('无法连接云端，请检查网络后重试')};const result=typeof response.result==='string'?JSON.parse(response.result):response.result;if(!result?.ok){const error=Object.assign(new Error(result?.error?.message||'云端暂时无法处理请求'),{code:result?.error?.code||'SERVICE_FAILED'});if(error.code==='UNAUTHENTICATED')window.dispatchEvent(new Event('our-space-session-expired'));throw error}return result.data as T;}
export interface SpaceInfo {settings:Settings;revision:number;memberCount:number;owner:boolean}
export async function getSpace(){const s=await rpc<SpaceInfo>('space');revision=s.revision;return s;}
export async function signIn(username:string,password:string){const client=await app();const result=await client.auth({persistence:'session'}).signInWithPassword({username,password});if(result.error)throw Error('登录失败，请检查账号或密码');}
export async function hasSession(){const client=await app();const response=await client.auth({persistence:'session'}).getSession();return !!(!response.error&&response.data?.session?.access_token);}
export async function signOut(){urlsToIds.clear();revision=0;const client=await app();await client.auth({persistence:'session'}).signOut();}
export function clearMediaCache(){urlsToIds.clear();}
export function currentRevision(){return revision;}

export const cloudStorage={
 async list():Promise<Memory[]>{const raw:Memory[]=[];let after:string|null='';do{const p:{records:Memory[];after:string|null}=await rpc<{records:Memory[];after:string|null}>('list',{after});raw.push(...p.records);after=p.after;}while(after);const ids=[...new Set(raw.flatMap(m=>m.images))];const resolved=new Map<string,string>();for(let i=0;i<ids.length;i+=50){const result=await rpc<{urls:{id:string;url:string}[]}>('urls',{ids:ids.slice(i,i+50)});for(const {id,url} of result.urls){if(!url.startsWith('https://'))throw Error('照片地址无效');resolved.set(id,url);urlsToIds.set(url,id);}}return raw.map(m=>({...m,images:m.images.map(id=>resolved.get(id)!)}));},
 async save(memory:Memory){const ids:string[]=[];for(const image of memory.images){if(image.startsWith('data:image/jpeg;base64,')){const result=await rpc<{id:string}>('upload',{data:image});ids.push(result.id);}else{const id=urlsToIds.get(image);if(!id)throw Error('照片地址已失效，请刷新后重新编辑');ids.push(id);}}await rpc('save',{memory:{...memory,images:ids}});},
 async settings(){return (await getSpace()).settings;},
 async saveSettings(settings:Settings){await rpc('settings',{settings});},
 async purgeExpired(_now:number){/* retention is enforced by the cloud maintenance function */},
 async trash(memory:Memory){await rpc('trash',{id:memory.id,version:memory.version})},
 async restore(memory:Memory){await rpc('restore',{id:memory.id,version:memory.version})},
 async removeTrashed(id:string,version:number){await rpc('remove',{id,version})}
};

export async function materializeImages(items:Memory[]):Promise<Memory[]>{const cache=new Map<string,string>();const asDataUrl=(blob:Blob)=>new Promise<string>((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result));reader.onerror=()=>reject(Error('读取照片失败'));reader.readAsDataURL(blob)});const result:Memory[]=[];let total=0;for(const item of items){const images=[];for(const url of item.images){if(url.startsWith('data:')){images.push(url);continue}let local=cache.get(url);if(!local){const response=await fetch(url,{credentials:'omit',cache:'no-store',referrerPolicy:'no-referrer'});if(!response.ok)throw Error('照片下载失败，请刷新后重新导出');const blob=await response.blob();total+=blob.size;if(total>100*1024*1024)throw Error('导出照片超过 100 MB，请减少单次导出内容');if(!blob.type.startsWith('image/'))throw Error('照片文件类型无效');local=await asDataUrl(blob);cache.set(url,local)}images.push(local)}result.push({...item,images})}return result;}
