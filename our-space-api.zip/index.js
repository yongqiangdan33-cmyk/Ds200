"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// cloud/index.ts
var index_exports = {};
__export(index_exports, {
  main: () => main
});
module.exports = __toCommonJS(index_exports);
var import_node_sdk = __toESM(require("@cloudbase/node-sdk"), 1);
var import_jpeg_js = __toESM(require("jpeg-js"), 1);

// cloud/core.ts
var import_node_crypto = require("node:crypto");

// src/domain.ts
var defaultSettings = { title: "\u6211\u4EEC\u7684\u5C0F\u65E5\u5B50", names: "\u4F60 & \u6211", startDate: "", timezone: "Asia/Shanghai" };
function localDate(now, zone = "Asia/Shanghai") {
  const p = new Intl.DateTimeFormat("en-CA", { timeZone: zone, year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(now);
  const v = (k) => p.find((x) => x.type === k)?.value;
  return `${v("year")}-${v("month")}-${v("day")}`;
}
function dayNumber(s) {
  const [y, m, d] = s.split("-").map(Number);
  const x = new Date(Date.UTC(y, m - 1, d));
  if (!y || !m || !d || x.getUTCFullYear() !== y || x.getUTCMonth() !== m - 1 || x.getUTCDate() !== d) throw Error("\u65E5\u671F\u65E0\u6548");
  return Math.floor(x.getTime() / 864e5);
}
function dayDifference(start, end) {
  return dayNumber(end) - dayNumber(start);
}

// cloud/core.ts
var ApiError = class extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
  }
  code;
};
var fail = (code, message) => {
  throw new ApiError(code, message);
};
var hash = (v) => (0, import_node_crypto.createHash)("sha256").update(v).digest("hex");
var isId = (v) => typeof v === "string" && /^[a-zA-Z0-9_-]{1,100}$/.test(v) && !["__proto__", "constructor", "prototype"].includes(v);
var text = (v, max) => {
  if (typeof v !== "string" || v.length > max) fail("VALIDATION", "\u6587\u5B57\u683C\u5F0F\u6216\u957F\u5EA6\u65E0\u6548");
  return v;
};
var date = (v, optional = false) => {
  if (optional && v === "") return "";
  if (typeof v !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(v)) fail("VALIDATION", "\u65E5\u671F\u683C\u5F0F\u65E0\u6548");
  try {
    dayDifference(v, v);
  } catch {
    fail("VALIDATION", "\u65E5\u671F\u65E0\u6548");
  }
  return v;
};
function validateSettings(v, now) {
  if (!v || typeof v !== "object") return fail("VALIDATION", "\u8BBE\u7F6E\u65E0\u6548");
  const x = v;
  const title = text(x.title, 40).trim(), names = text(x.names, 40).trim();
  if (!title || !names) fail("VALIDATION", "\u8BF7\u586B\u5199\u540D\u79F0");
  const timezone = text(x.timezone, 80);
  try {
    localDate(new Date(now), timezone);
  } catch {
    fail("VALIDATION", "\u65F6\u533A\u65E0\u6548");
  }
  const startDate = date(x.startDate, true);
  if (startDate && startDate > localDate(new Date(now), timezone)) fail("VALIDATION", "\u5F00\u59CB\u65E5\u671F\u4E0D\u80FD\u665A\u4E8E\u4ECA\u5929");
  return { title, names, startDate, timezone, version: 0 };
}
function validateMemory(v) {
  if (!v || typeof v !== "object") return fail("VALIDATION", "\u8BB0\u5F55\u65E0\u6548");
  const x = v;
  if (!isId(x.id) || !["photo", "artifact", "occasion", "wish"].includes(x.kind)) fail("VALIDATION", "\u8BB0\u5F55\u7C7B\u578B\u65E0\u6548");
  const title = text(x.title, 80).trim(), story = text(x.story, x.kind === "artifact" ? 1e4 : 2e3);
  if (x.kind !== "photo" && !title) fail("VALIDATION", "\u8BF7\u586B\u5199\u6807\u9898");
  const d = date(x.date, true), year = text(x.year, 4);
  if (year && !/^(19|[2-9]\d)\d{2}$/.test(year)) fail("VALIDATION", "\u5E74\u4EFD\u65E0\u6548");
  if (x.kind === "occasion" && !d) fail("VALIDATION", "\u91CD\u8981\u65E5\u5B50\u9700\u8981\u65E5\u671F");
  if (!Array.isArray(x.images) || x.images.length > 20 || x.images.some((i) => !isId(i))) fail("VALIDATION", "\u7167\u7247\u5F15\u7528\u65E0\u6548");
  if (["photo", "artifact"].includes(x.kind) && x.images.length === 0) fail("VALIDATION", "\u81F3\u5C11\u9700\u8981\u4E00\u5F20\u7167\u7247");
  if (!["photo", "artifact"].includes(x.kind) && x.images.length) fail("VALIDATION", "\u6B64\u8BB0\u5F55\u4E0D\u652F\u6301\u56FE\u7247");
  if (x.version !== void 0 && (!Number.isSafeInteger(x.version) || x.version < 1)) fail("VALIDATION", "\u7248\u672C\u65E0\u6548");
  return { id: x.id, kind: x.kind, title, story, date: d, year: d ? "" : year, images: [...x.images], done: !!x.done, repeat: !!x.repeat, createdAt: 0, version: x.version };
}
function createApi(repo2, media2, options) {
  const now = options.now ?? Date.now;
  async function state(tx, uid, initialize = false) {
    if (!uid) fail("UNAUTHENTICATED", "\u8BF7\u91CD\u65B0\u767B\u5F55");
    let s = await tx.get("spaces", "singleton");
    if (!s && initialize && options.ownerUid && uid === options.ownerUid) {
      s = { id: "singleton", members: [uid], settings: { ...defaultSettings, version: 1 }, revision: 1, slots: {} };
      await tx.set("spaces", "singleton", s);
    }
    if (!s || !s.members.includes(uid)) return fail("FORBIDDEN", "\u8FD9\u4E2A\u7A7A\u95F4\u4EC5\u9650\u5DF2\u7ED1\u5B9A\u7684\u4E24\u4E2A\u4EBA");
    return s;
  }
  async function member(uid) {
    return state(repo2, uid);
  }
  const bump = async (tx, s) => {
    s.revision++;
    await tx.set("spaces", "singleton", s);
  };
  async function mutation(uid, id, version, mode) {
    if (!isId(id)) fail("VALIDATION", "\u8BB0\u5F55\u65E0\u6548");
    return repo2.transaction(async (tx) => {
      const s = await state(tx, uid);
      const m = await tx.get("memories", id);
      if (!m) fail("NOT_FOUND", "\u8BB0\u5F55\u4E0D\u5B58\u5728");
      if (m.version !== version) fail("CONFLICT", "\u8BB0\u5F55\u5DF2\u88AB\u53E6\u4E00\u65B9\u4FEE\u6539\uFF0C\u8BF7\u5237\u65B0\u540E\u91CD\u8BD5");
      if (mode === "remove") {
        if (!m.deletedAt) fail("CONFLICT", "\u8BB0\u5F55\u5DF2\u7ECF\u6062\u590D\uFF0C\u4E0D\u80FD\u5220\u9664");
        await tx.remove("memories", id);
        delete s.slots[id];
      } else {
        if (mode === "restore" && (!m.deletedAt || now() - m.deletedAt >= 30 * 864e5)) fail("CONFLICT", "\u8BB0\u5F55\u65E0\u6CD5\u6062\u590D");
        const updated = { ...m, version: m.version + 1, updatedAt: now() };
        if (mode === "trash") {
          updated.deletedAt = now();
          delete s.slots[id];
        } else {
          delete updated.deletedAt;
          if (m.kind === "artifact") {
            updated.slot = freeSlot(s.slots);
            s.slots[id] = updated.slot;
          }
        }
        await tx.set("memories", id, updated);
      }
      await bump(tx, s);
      return { ok: true };
    });
  }
  function freeSlot(slots) {
    const used = new Set(Object.values(slots));
    let i = 0;
    while (used.has(i)) i++;
    return i;
  }
  return async function dispatch2(uid, request) {
    if (!uid) fail("UNAUTHENTICATED", "\u8BF7\u767B\u5F55");
    if (!request || typeof request !== "object") fail("VALIDATION", "\u8BF7\u6C42\u65E0\u6548");
    const r = request;
    const x = r.input ?? {};
    switch (r.action) {
      case "space":
        return repo2.transaction(async (tx) => {
          const s = await state(tx, uid, true);
          return { settings: s.settings, revision: s.revision, memberCount: s.members.length, owner: uid === options.ownerUid };
        });
      case "invite":
        return repo2.transaction(async (tx) => {
          const s = await state(tx, uid);
          if (uid !== options.ownerUid) fail("FORBIDDEN", "\u53EA\u6709\u7A7A\u95F4\u521B\u5EFA\u8005\u53EF\u4EE5\u9080\u8BF7");
          if (s.members.length >= 2) fail("SPACE_FULL", "\u7A7A\u95F4\u5DF2\u7ED1\u5B9A\u4E24\u4EBA");
          const token = options.token?.() ?? (0, import_node_crypto.randomBytes)(24).toString("hex");
          s.invite = { hash: hash(token), expiresAt: now() + 864e5 };
          await bump(tx, s);
          return { token, expiresAt: s.invite.expiresAt };
        });
      case "join":
        return repo2.transaction(async (tx) => {
          const s = await tx.get("spaces", "singleton");
          if (s?.members.includes(uid)) return { ok: true };
          if (!s || s.members.length >= 2) fail("SPACE_FULL", "\u7A7A\u95F4\u5DF2\u6EE1\u6216\u5C1A\u672A\u521D\u59CB\u5316");
          if (typeof x.token !== "string" || x.token.length > 100 || !s.invite || s.invite.expiresAt <= now() || hash(x.token) !== s.invite.hash) fail("EXPIRED_INVITE", "\u9080\u8BF7\u65E0\u6548\u6216\u5DF2\u8FC7\u671F");
          s.members.push(uid);
          delete s.invite;
          await bump(tx, s);
          return { ok: true };
        });
      case "settings": {
        const next = validateSettings(x.settings, now());
        return repo2.transaction(async (tx) => {
          const s = await state(tx, uid);
          if (s.settings.version !== x.settings.version) fail("CONFLICT", "\u8BBE\u7F6E\u5DF2\u6539\u53D8\uFF0C\u8BF7\u5237\u65B0\u540E\u91CD\u65B0\u7F16\u8F91");
          next.version = (s.settings.version ?? 0) + 1;
          s.settings = next;
          await bump(tx, s);
          return next;
        });
      }
      case "list": {
        await member(uid);
        const after = x.after ?? "";
        if (after !== "" && !isId(after)) fail("VALIDATION", "\u5206\u9875\u4F4D\u7F6E\u65E0\u6548");
        const records = await repo2.page("memories", after, 50);
        return { records: records.map(({ requestHash, ...m }) => m), after: records.length === 50 ? records.at(-1).id : null };
      }
      case "save": {
        const value = validateMemory(x.memory);
        const fingerprint = hash(JSON.stringify(value));
        return repo2.transaction(async (tx) => {
          const s = await state(tx, uid);
          const old = await tx.get("memories", value.id);
          if (old?.requestHash === fingerprint) return { ok: true };
          if (old ? old.version !== value.version : value.version !== void 0) fail("CONFLICT", "\u8FD9\u6761\u8BB0\u5F55\u5DF2\u6539\u53D8\uFF0C\u8BF7\u5237\u65B0\u540E\u91CD\u65B0\u7F16\u8F91");
          if (old?.deletedAt) fail("CONFLICT", "\u8FD9\u6761\u8BB0\u5F55\u5DF2\u5728\u56DE\u6536\u7AD9");
          if (old && old.kind !== value.kind) fail("VALIDATION", "\u4E0D\u80FD\u6539\u53D8\u5DF2\u6709\u8BB0\u5F55\u7684\u7C7B\u578B");
          for (const id of value.images) {
            const image = await tx.get("media", id);
            if (!image || image.state === "deleting") fail("VALIDATION", "\u7167\u7247\u5C1A\u672A\u4E0A\u4F20\u5B8C\u6210\uFF0C\u8BF7\u91CD\u8BD5");
          }
          const m = { ...value, createdAt: old?.createdAt ?? now(), createdBy: old?.createdBy ?? uid, updatedAt: now(), version: (old?.version ?? 0) + 1, requestHash: fingerprint };
          if (value.kind === "artifact") {
            m.slot = s.slots[value.id] ?? freeSlot(s.slots);
            s.slots[value.id] = m.slot;
          }
          await tx.set("memories", m.id, m);
          await bump(tx, s);
          return { ok: true };
        });
      }
      case "trash":
      case "restore":
      case "remove":
        return mutation(uid, x.id, x.version, r.action);
      case "upload": {
        await member(uid);
        if (typeof x.data !== "string" || !/^data:image\/jpeg;base64,/.test(x.data) || x.data.length > 22e5) fail("VALIDATION", "\u7167\u7247\u683C\u5F0F\u6216\u5927\u5C0F\u65E0\u6548\uFF0C\u8BF7\u6362\u4E00\u5F20\u8F83\u5C0F\u7684\u7167\u7247");
        const data = x.data;
        const id = hash(data);
        const existing = await repo2.get("media", id);
        if (existing?.state === "deleting") fail("CONFLICT", "\u7167\u7247\u6B63\u5728\u6574\u7406\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5");
        if (existing) return { id };
        const fileId = await media2.put(id, data.slice(data.indexOf(",") + 1));
        await repo2.transaction(async (tx) => {
          const s = await state(tx, uid);
          const current = await tx.get("media", id);
          if (current?.state === "deleting") fail("CONFLICT", "\u7167\u7247\u6B63\u5728\u6574\u7406\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5");
          await tx.set("media", id, { id, fileId, createdAt: now(), state: "ready" });
          await bump(tx, s);
        });
        return { id };
      }
      case "urls": {
        await member(uid);
        if (!Array.isArray(x.ids) || x.ids.length > 50 || x.ids.some((v) => !isId(v))) fail("VALIDATION", "\u7167\u7247\u8BF7\u6C42\u65E0\u6548");
        const docs = await Promise.all(x.ids.map((id) => repo2.get("media", id)));
        if (docs.some((v) => !v || v.state === "deleting")) fail("NOT_FOUND", "\u7167\u7247\u4E0D\u5B58\u5728\u6216\u6B63\u5728\u6574\u7406");
        const urls = await media2.url(docs.map((d) => d.fileId));
        return { urls: x.ids.map((id, i) => ({ id, url: urls[i] })), expiresAt: now() + 3e5 };
      }
      default:
        return fail("VALIDATION", "\u4E0D\u652F\u6301\u7684\u64CD\u4F5C");
    }
  };
}

// cloud/repository.ts
var check = (response) => {
  if (response?.code) throw Object.assign(Error("Cloud database request failed"), { code: response.code });
  return response;
};
function access(source) {
  return {
    async get(collection, id) {
      const response = check(await source.collection(collection).doc(id).get());
      const data = Array.isArray(response.data) ? response.data[0] : response.data;
      if (!data) return null;
      const { _id, ...value } = data;
      return value;
    },
    async set(collection, id, value) {
      check(await source.collection(collection).doc(id).set(value));
    },
    async remove(collection, id) {
      check(await source.collection(collection).doc(id).remove());
    }
  };
}
function createRepository(db) {
  return { ...access(db), async transaction(fn) {
    return db.runTransaction(async (tx) => fn(access(tx)));
  }, async page(collection, after, limit) {
    let query = db.collection(collection).orderBy("_id", "asc").limit(limit);
    if (after) query = query.where({ _id: db.command.gt(after) });
    const response = check(await query.get());
    return response.data.map(({ _id, ...value }) => value);
  } };
}

// cloud/index.ts
var app = import_node_sdk.default.init({ env: import_node_sdk.default.SYMBOL_CURRENT_ENV });
var repo = createRepository(app.database());
var media = {
  async put(id, base64) {
    let input;
    try {
      input = Buffer.from(base64, "base64");
      if (input.toString("base64") !== base64) throw Error();
    } catch {
      throw new ApiError("VALIDATION", "\u7167\u7247\u683C\u5F0F\u65E0\u6548");
    }
    ;
    if (input.length > 165e4) throw new ApiError("VALIDATION", "\u7167\u7247\u5C55\u793A\u7248\u672C\u8FC7\u5927");
    let decoded;
    try {
      decoded = import_jpeg_js.default.decode(input, { maxResolutionInMP: 6, maxMemoryUsageInMB: 128, tolerantDecoding: false });
    } catch {
      throw new ApiError("VALIDATION", "\u65E0\u6CD5\u8BFB\u53D6\u8FD9\u5F20\u7167\u7247");
    }
    ;
    if (decoded.width > 2400 || decoded.height > 2400 || !decoded.width || !decoded.height) throw new ApiError("VALIDATION", "\u7167\u7247\u5C3A\u5BF8\u65E0\u6548");
    const clean = import_jpeg_js.default.encode({ width: decoded.width, height: decoded.height, data: decoded.data }, 85).data;
    const response = await app.uploadFile({ cloudPath: `our-space/${id}.jpg`, fileContent: clean });
    if (!response.fileID) throw new ApiError("MEDIA_FAILED", "\u7167\u7247\u4E0A\u4F20\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5");
    return response.fileID;
  },
  async url(fileIds) {
    const response = await app.getTempFileURL({ fileList: fileIds.map((fileID) => ({ fileID, maxAge: 300 })) });
    const map = new Map(response.fileList.map((x) => [x.fileID, x]));
    return fileIds.map((id) => {
      const entry = map.get(id);
      if (!entry?.tempFileURL || entry.code !== "SUCCESS") throw new ApiError("MEDIA_FAILED", "\u7167\u7247\u6682\u65F6\u65E0\u6CD5\u8BFB\u53D6");
      return entry.tempFileURL;
    });
  }
};
var dispatch = createApi(repo, media, { ownerUid: process.env.SPACE_OWNER_UID ?? "" });
async function main(event) {
  try {
    const identity = app.auth().getUserInfo();
    if (!identity?.uid || identity.isAnonymous) throw new ApiError("UNAUTHENTICATED", "\u8BF7\u4F7F\u7528\u6B63\u5F0F\u8D26\u53F7\u767B\u5F55");
    if (!process.env.SPACE_OWNER_UID) throw new ApiError("CONFIGURATION", "\u7A7A\u95F4\u5C1A\u672A\u914D\u7F6E");
    return { ok: true, data: await dispatch(identity.uid, event) };
  } catch (error) {
    if (error instanceof ApiError) return { ok: false, error: { code: error.code, message: error.message } };
    return { ok: false, error: { code: "SERVICE_FAILED", message: "\u670D\u52A1\u6682\u65F6\u65E0\u6CD5\u5B8C\u6210\u8BF7\u6C42\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5" } };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  main
});
