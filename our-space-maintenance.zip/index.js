"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// cloud/maintenance.ts
var maintenance_exports = {};
__export(maintenance_exports, {
  main: () => main
});
module.exports = __toCommonJS(maintenance_exports);
var import_node_sdk = __toESM(require("@cloudbase/node-sdk"), 1);

// cloud/repository.ts
var check = (response) => {
  if (response?.code) throw Object.assign(Error("Cloud database request failed"), { code: response.code });
  return response;
};
function access(source) {
  return {
    async get(collection, id) {
      const response = check(await source.collection(collection).doc(id).get());
      const data = Array.isArray(response.data) ? response.data[0] : response.data;
      if (!data) return null;
      const { _id, ...value } = data;
      return value;
    },
    async set(collection, id, value) {
      check(await source.collection(collection).doc(id).set(value));
    },
    async remove(collection, id) {
      check(await source.collection(collection).doc(id).remove());
    }
  };
}
function createRepository(db) {
  return { ...access(db), async transaction(fn) {
    return db.runTransaction(async (tx) => fn(access(tx)));
  }, async page(collection, after, limit) {
    let query = db.collection(collection).orderBy("_id", "asc").limit(limit);
    if (after) query = query.where({ _id: db.command.gt(after) });
    const response = check(await query.get());
    return response.data.map(({ _id, ...value }) => value);
  } };
}

// cloud/retention.ts
async function runRetention(repo, deleteFile, now) {
  let recordsRemoved = 0, filesRemoved = 0;
  async function all(collection) {
    const records = [];
    let after2 = "";
    for (; ; ) {
      const page = await repo.page(collection, after2, 50);
      records.push(...page);
      if (page.length < 50) break;
      after2 = page.at(-1).id;
    }
    return records;
  }
  for (const item of await all("memories")) {
    const removed = await repo.transaction(async (tx) => {
      const current = await tx.get("memories", item.id);
      if (!current?.deletedAt || now - current.deletedAt < 30 * 864e5) return false;
      const s = await tx.get("spaces", "singleton");
      if (!s) return false;
      delete s.slots[item.id];
      s.revision++;
      await tx.remove("memories", item.id);
      await tx.set("spaces", "singleton", s);
      return true;
    });
    if (removed) recordsRemoved++;
  }
  const before = await repo.get("spaces", "singleton");
  if (!before) return { recordsRemoved, filesRemoved };
  const references = new Set((await all("memories")).flatMap((m) => m.images));
  const after = await repo.get("spaces", "singleton");
  if (after?.revision !== before.revision) return { recordsRemoved, filesRemoved };
  let expected = before.revision;
  for (const candidate of await all("media")) {
    if (references.has(candidate.id) || now - candidate.createdAt < 864e5) continue;
    const marked = await repo.transaction(async (tx) => {
      const s = await tx.get("spaces", "singleton");
      if (!s || s.revision !== expected) return null;
      const m = await tx.get("media", candidate.id);
      if (!m || m.fileId !== candidate.fileId || now - m.createdAt < 864e5) return null;
      m.state = "deleting";
      s.revision++;
      await tx.set("media", m.id, m);
      await tx.set("spaces", "singleton", s);
      return { fileId: m.fileId, revision: s.revision };
    });
    if (!marked) break;
    expected = marked.revision;
    await deleteFile(marked.fileId);
    const end = await repo.transaction(async (tx) => {
      const s = await tx.get("spaces", "singleton");
      const m = await tx.get("media", candidate.id);
      if (!s || m?.state !== "deleting" || m.fileId !== marked.fileId) throw Error("Media cleanup changed unexpectedly");
      const concurrent = s.revision !== expected;
      await tx.remove("media", candidate.id);
      s.revision++;
      await tx.set("spaces", "singleton", s);
      return { concurrent, revision: s.revision };
    });
    filesRemoved++;
    expected = end.revision;
    if (end.concurrent) break;
  }
  return { recordsRemoved, filesRemoved };
}

// cloud/maintenance.ts
var app = import_node_sdk.default.init({ env: import_node_sdk.default.SYMBOL_CURRENT_ENV });
async function main() {
  return runRetention(createRepository(app.database()), async (fileId) => {
    const result = await app.deleteFile({ fileList: [fileId] });
    if (result.fileList.some((x) => x.code !== "SUCCESS")) throw Error("File cleanup failed");
  }, Date.now());
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  main
});
